package Assignment_Operators_I;

public class arithmeticOperatorsRCD {
    public static void main(String[] args){
        int num1 = 10;
        int num2 = 5;
        int sum = num1 + num2;
        int difference = num1 - num2;
        int product = num1 * num2;
        int quotient = num1 / num2;

        System.out.println(num1 + " + " + num2 + " = " + sum );
        System.out.println(num1 + " - " + num2 + " = " + difference );
        System.out.println(num1 + " * " + num2 + " = " + product );
        System.out.println(num1 + " / " + num2 + " = " + quotient );
        
    }
}
